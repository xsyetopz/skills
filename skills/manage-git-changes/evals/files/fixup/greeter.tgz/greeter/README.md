# greeter

Say hello and goodbye.

Draft: add French.
