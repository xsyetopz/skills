MESSAGES = {
    "en": "Thank you for visitng.",
    "de": "Danke fuer Ihren Besuch.",
}
