import unittest

from greeter.core import farewell
from greeter.messages import MESSAGES


class FarewellTest(unittest.TestCase):
    def test_farewell(self):
        self.assertEqual(farewell("Ada"), "Goodbye, Ada!")

    def test_english_message(self):
        self.assertEqual(MESSAGES["en"], "Thank you for visiting.")
