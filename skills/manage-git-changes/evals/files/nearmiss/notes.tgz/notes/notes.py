def add(note, store):
    store.append(note)
    return store


def search(term, store):
    return [n for n in store if term.lower() in n.lower()]
