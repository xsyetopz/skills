# csvtool

A tiny CSV splitter that understands quoted fields.

Run the tests with `python3 -m unittest`.
