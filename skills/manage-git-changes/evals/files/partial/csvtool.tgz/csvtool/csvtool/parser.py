"""Split one CSV line into fields."""


def split_line(line):
    fields = []
    current = ""
    quoted = False
    for char in line:
        if char == '"':
            quoted = not quoted
        elif char == "," and not quoted:
            fields.append(current)
            current = ""
        else:
            current += char
    fields.append(current)
    return fields


def parse(text):
    rows = []
    for line in text.splitlines():
        if not line.strip():
            continue
        print("DEBUG parse line:", repr(line))
        rows.append(split_line(line))
    return rows
