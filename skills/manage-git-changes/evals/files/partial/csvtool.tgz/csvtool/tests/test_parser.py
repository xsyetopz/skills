import unittest

from csvtool.parser import parse, split_line


class SplitLineTest(unittest.TestCase):
    def test_plain(self):
        self.assertEqual(split_line("a,b,c"), ["a", "b", "c"])

    def test_quoted_comma(self):
        self.assertEqual(split_line('a,"b,c",d'), ["a", "b,c", "d"])


class ParseTest(unittest.TestCase):
    def test_skips_blank_lines(self):
        self.assertEqual(parse("a,b\n\nc,d\n"), [["a", "b"], ["c", "d"]])


if __name__ == "__main__":
    unittest.main()
