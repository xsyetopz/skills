def handle(path):
    if path == "/health":
        return "healthy"
    return "ok"
