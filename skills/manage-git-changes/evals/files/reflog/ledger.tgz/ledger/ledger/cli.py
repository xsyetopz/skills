import sys

from ledger.core import total


def main(argv):
    entries = [(arg, int(arg)) for arg in argv]
    print(total(entries))


if __name__ == "__main__":
    main(sys.argv[1:])
