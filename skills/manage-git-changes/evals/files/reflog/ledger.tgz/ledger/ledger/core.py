def total(entries):
    return sum(amount for _, amount in entries)
