CURRENCY = "EUR"
ROUNDING = 2  # work in progress
