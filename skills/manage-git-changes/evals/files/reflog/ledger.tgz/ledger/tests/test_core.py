import unittest

from ledger.core import total


class TotalTest(unittest.TestCase):
    def test_total(self):
        self.assertEqual(total([("a", 2), ("b", 3)]), 5)
