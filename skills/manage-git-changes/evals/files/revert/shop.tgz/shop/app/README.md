# Shop

Prices are integers in cents.
Run `python3 -m unittest`.
