from shop.discounts import apply_discount


def cart_total(items):
    return apply_discount(sum(price * qty for price, qty in items))
