def apply_discount(total):
    return total - total // 10 - 1
