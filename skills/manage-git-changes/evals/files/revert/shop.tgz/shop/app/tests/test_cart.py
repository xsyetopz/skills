import unittest

from shop.cart import cart_total


class CartTest(unittest.TestCase):
    def test_total(self):
        self.assertEqual(cart_total([(250, 2), (100, 1)]), 600)

    def test_empty(self):
        self.assertEqual(cart_total([]), 0)
