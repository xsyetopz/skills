def limit(n):
    """Clamp a page size to 0..100."""
    return max(0, min(n, 100))
